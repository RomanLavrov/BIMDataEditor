# ForgeSdk.Diagnostics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**diagnostics** | **String** | reason for failure | 


