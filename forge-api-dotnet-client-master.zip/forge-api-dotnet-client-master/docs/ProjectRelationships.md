# Autodesk.Forge.Model.ProjectRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hub** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**RootFolder** | [**JsonApiRelationshipsLinksExternalResource**](JsonApiRelationshipsLinksExternalResource.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

