# ForgeSdk.CreateItemIncluded

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**id** | **String** |  | 
**attributes** | [**CreateStorageDataAttributes**](CreateStorageDataAttributes.md) |  | [optional] 
**relationships** | [**CreateItemRelationships**](CreateItemRelationships.md) |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `versions` (value: `"versions"`)




<a name="IdEnum"></a>
## Enum: IdEnum


* `1` (value: `"1"`)




