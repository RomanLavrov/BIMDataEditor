# ForgeSdk.ActivityVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Integer** |  | [optional] 


