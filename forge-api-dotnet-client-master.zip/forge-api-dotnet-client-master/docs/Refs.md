# Autodesk.Forge.Model.Refs
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**Data** | [**List&lt;RelRef&gt;**](RelRef.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

