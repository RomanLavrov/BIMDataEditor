# Autodesk.Forge.Model.BucketObjects
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Items** | [**List&lt;ObjectDetails&gt;**](ObjectDetails.md) |  | [optional] 
**Next** | **string** | Next possible request | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

