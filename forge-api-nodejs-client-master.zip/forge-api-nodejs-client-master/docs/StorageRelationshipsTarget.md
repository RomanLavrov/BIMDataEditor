# ForgeSdk.StorageRelationshipsTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**JsonApiLinksRelated**](JsonApiLinksRelated.md) |  | 
**data** | [**StorageRelationshipsTargetData**](StorageRelationshipsTargetData.md) |  | [optional] 


