# ForgeSdk.WorkItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**_arguments** | **Object** |  | 
**status** | **String** |  | [optional] 
**statusDetail** | **Object** |  | [optional] 
**availabilityZone** | **String** |  | [optional] 
**activityId** | **String** |  | 
**version** | **Integer** |  | [optional] 
**timestamp** | **String** |  | [optional] 


