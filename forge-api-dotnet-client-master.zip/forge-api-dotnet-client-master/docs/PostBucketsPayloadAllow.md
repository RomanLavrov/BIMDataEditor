# Autodesk.Forge.Model.PostBucketsPayloadAllow
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AuthId** | **string** | The application key to grant access to | 
**Access** | **string** | Acceptable values: &#x60;full&#x60; or &#x60;read&#x60;  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

