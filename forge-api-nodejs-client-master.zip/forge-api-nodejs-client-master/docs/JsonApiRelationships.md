# ForgeSdk.JsonApiRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


