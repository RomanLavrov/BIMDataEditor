# ForgeSdk.JobThumbnailOutputPayloadAdvanced

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Integer** | Set the width. Possible values are &#x60;100&#x60;, &#x60;200&#x60; and &#x60;400&#x60;. | [optional] 
**height** | **Integer** | Set the height. Possible values are &#x60;100&#x60;, &#x60;200&#x60; and &#x60;400&#x60;. | [optional] 


