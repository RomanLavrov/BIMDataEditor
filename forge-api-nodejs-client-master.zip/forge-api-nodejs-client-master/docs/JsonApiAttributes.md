# ForgeSdk.JsonApiAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


