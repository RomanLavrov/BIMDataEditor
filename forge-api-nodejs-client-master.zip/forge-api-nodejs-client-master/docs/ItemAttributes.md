# ForgeSdk.ItemAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**displayName** | **String** | displayable name of the item | 
**extension** | [**BaseAttributesExtensionObject**](BaseAttributesExtensionObject.md) |  | 


