# ForgeSdk.CreateItemDataRelationshipsTip

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**CreateItemDataRelationshipsTipData**](CreateItemDataRelationshipsTipData.md) |  | [optional] 


