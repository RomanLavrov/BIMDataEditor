# ForgeSdk.VersionRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**refs** | [**JsonApiRelationshipsLinksRefs**](JsonApiRelationshipsLinksRefs.md) |  | 
**storage** | [**JsonApiRelationshipsLinksExternalResource**](JsonApiRelationshipsLinksExternalResource.md) |  | [optional] 
**derivatives** | [**JsonApiRelationshipsLinksExternalResource**](JsonApiRelationshipsLinksExternalResource.md) |  | [optional] 
**thumbnails** | [**JsonApiRelationshipsLinksExternalResource**](JsonApiRelationshipsLinksExternalResource.md) |  | [optional] 


