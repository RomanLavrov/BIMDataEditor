# Autodesk.Forge.Model.JobThumbnailOutputPayloadAdvanced
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Width** | **int?** | Set the width. Possible values are &#x60;100&#x60;, &#x60;200&#x60; and &#x60;400&#x60;. | [optional] 
**Height** | **int?** | Set the height. Possible values are &#x60;100&#x60;, &#x60;200&#x60; and &#x60;400&#x60;. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

