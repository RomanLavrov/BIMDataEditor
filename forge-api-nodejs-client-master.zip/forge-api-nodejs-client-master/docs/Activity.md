# ForgeSdk.Activity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**instruction** | **Object** |  | 
**appPackages** | **[String]** |  | 
**requiredEngineVersion** | **String** |  | 
**parameters** | **Object** |  | 
**allowedChildProcesses** | **[Object]** |  | 
**version** | **Integer** |  | 
**description** | **String** |  | [optional] 
**hostApplication** | **String** |  | [optional] 
**isPublic** | **Boolean** |  | 


