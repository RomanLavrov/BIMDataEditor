# ForgeSdk.DesignAutomationEngines

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[Engine]**](Engine.md) |  | [optional] 


