# Autodesk.Forge.Model.AppPackageOptional
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Resource** | **string** |  | [optional] 
**References** | **List&lt;string&gt;** |  | [optional] 
**RequiredEngineVersion** | **string** |  | [optional] 
**Version** | **int?** |  | [optional] 
**Description** | **string** |  | [optional] 
**IsPublic** | **bool?** |  | [optional] 
**IsObjectEnabler** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

