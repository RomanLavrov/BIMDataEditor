# ForgeSdk.DesignAutomationWorkItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[WorkItemResp]**](WorkItemResp.md) |  | [optional] 


