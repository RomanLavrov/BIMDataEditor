# Autodesk.Forge.Model.HubRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Projects** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

