# ForgeSdk.AppPackage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**resource** | **String** |  | 
**references** | **[String]** |  | 
**requiredEngineVersion** | **String** |  | 
**version** | **Integer** |  | 
**description** | **String** |  | [optional] 
**isPublic** | **Boolean** |  | [optional] 
**isObjectEnabler** | **Boolean** |  | [optional] 


