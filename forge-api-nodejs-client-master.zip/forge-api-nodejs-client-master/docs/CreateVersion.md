# ForgeSdk.CreateVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**CreateVersionData**](CreateVersionData.md) |  | [optional] 


