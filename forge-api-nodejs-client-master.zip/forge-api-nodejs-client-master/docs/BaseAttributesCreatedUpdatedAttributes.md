# ForgeSdk.BaseAttributesCreatedUpdatedAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**createTime** | **Date** |  | 
**createUserId** | **String** |  | 
**lastModifiedTime** | **Date** |  | 
**lastModifiedUserId** | **String** |  | 


