# ForgeSdk.ProjectAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | displayable name of the project | 
**extension** | [**BaseAttributesExtensionObject**](BaseAttributesExtensionObject.md) |  | 


