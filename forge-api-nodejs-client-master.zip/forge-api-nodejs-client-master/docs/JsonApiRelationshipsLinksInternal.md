# ForgeSdk.JsonApiRelationshipsLinksInternal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**JsonApiLinksRelated**](JsonApiLinksRelated.md) |  | 


