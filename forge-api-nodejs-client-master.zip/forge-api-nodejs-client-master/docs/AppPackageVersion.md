# ForgeSdk.AppPackageVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **Integer** |  | [optional] 


