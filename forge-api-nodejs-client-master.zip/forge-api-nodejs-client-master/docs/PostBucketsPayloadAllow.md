# ForgeSdk.PostBucketsPayloadAllow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authId** | **String** | The application key to grant access to | 
**access** | **String** | Acceptable values: &#x60;full&#x60; or &#x60;read&#x60;  | 


<a name="AccessEnum"></a>
## Enum: AccessEnum


* `full` (value: `"full"`)

* `read` (value: `"read"`)




