# Autodesk.Forge.Model.CreateStorageData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** |  | 
**Attributes** | [**CreateStorageDataAttributes**](CreateStorageDataAttributes.md) |  | [optional] 
**Relationships** | [**CreateStorageDataRelationships**](CreateStorageDataRelationships.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

