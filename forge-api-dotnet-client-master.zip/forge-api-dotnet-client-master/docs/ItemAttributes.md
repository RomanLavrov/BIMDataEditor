# Autodesk.Forge.Model.ItemAttributes
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisplayName** | **string** | displayable name of the item | 
**Extension** | [**BaseAttributesExtensionObject**](BaseAttributesExtensionObject.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

