# Autodesk.Forge.Model.Diagnostics
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Diagnostics** | **string** | reason for failure | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

