# ForgeSdk.CreateItemRelationshipsStorage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**CreateItemRelationshipsStorageData**](CreateItemRelationshipsStorageData.md) |  | [optional] 


