# Autodesk.Forge.Model.JobAcceptedJobs
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Output** | **Object** | identical to the request body. For more information please see the request body structure above. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

