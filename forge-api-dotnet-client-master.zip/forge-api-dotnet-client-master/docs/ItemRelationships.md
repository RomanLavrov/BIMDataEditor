# Autodesk.Forge.Model.ItemRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Parent** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**Tip** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**Versions** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 
**Refs** | [**JsonApiRelationshipsLinksRefs**](JsonApiRelationshipsLinksRefs.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

