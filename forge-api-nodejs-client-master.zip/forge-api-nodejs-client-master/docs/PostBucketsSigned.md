# ForgeSdk.PostBucketsSigned

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minutesExpiration** | **Integer** | Expiration time in minutes Default value: 60  | [default to 60]


