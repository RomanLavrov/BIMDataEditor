# ForgeSdk.JsonApiLinksPaging

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**prev** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**next** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**last** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 


