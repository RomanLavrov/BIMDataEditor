# ForgeSdk.CreateStorageDataRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target** | [**CreateStorageDataRelationshipsTarget**](CreateStorageDataRelationshipsTarget.md) |  | [optional] 


