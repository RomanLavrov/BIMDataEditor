# ForgeSdk.CreateItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**CreateItemData**](CreateItemData.md) |  | [optional] 
**included** | [**[CreateItemIncluded]**](CreateItemIncluded.md) |  | 


