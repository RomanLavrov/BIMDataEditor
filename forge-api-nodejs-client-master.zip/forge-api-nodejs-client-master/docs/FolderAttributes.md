# ForgeSdk.FolderAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | filename used when synced to local disk | 
**displayName** | **String** | displayable name of the folder | 
**objectCount** | **Integer** | number of contained sub-folders and items | 
**extension** | [**BaseAttributesExtensionObject**](BaseAttributesExtensionObject.md) |  | 


