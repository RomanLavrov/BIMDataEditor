# ForgeSdk.CreateRef

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**CreateRefData**](CreateRefData.md) |  | [optional] 


