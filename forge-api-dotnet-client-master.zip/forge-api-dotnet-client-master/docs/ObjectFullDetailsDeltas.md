# Autodesk.Forge.Model.ObjectFullDetailsDeltas
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Position** | **int?** |  | [optional] 
**Sha1** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

