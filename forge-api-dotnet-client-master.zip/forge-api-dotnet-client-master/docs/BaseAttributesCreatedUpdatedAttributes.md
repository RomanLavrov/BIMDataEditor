# Autodesk.Forge.Model.BaseAttributesCreatedUpdatedAttributes
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreateTime** | **DateTime?** |  | 
**CreateUserId** | **string** |  | 
**LastModifiedTime** | **DateTime?** |  | 
**LastModifiedUserId** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

