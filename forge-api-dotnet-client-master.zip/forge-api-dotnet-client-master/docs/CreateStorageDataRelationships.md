# Autodesk.Forge.Model.CreateStorageDataRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Target** | [**CreateStorageDataRelationshipsTarget**](CreateStorageDataRelationshipsTarget.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

