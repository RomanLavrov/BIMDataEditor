# ForgeSdk.FolderRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | [optional] 
**contents** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 
**refs** | [**JsonApiRelationshipsLinksRefs**](JsonApiRelationshipsLinksRefs.md) |  | 


