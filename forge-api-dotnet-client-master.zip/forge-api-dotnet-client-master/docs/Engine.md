# Autodesk.Forge.Model.Engine
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Resource** | **string** |  | [optional] 
**IsPublic** | **bool?** |  | [optional] 
**Version** | **int?** |  | [optional] 
**Timestamp** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

