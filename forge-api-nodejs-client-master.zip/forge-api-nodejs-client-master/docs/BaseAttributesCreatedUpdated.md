# ForgeSdk.BaseAttributesCreatedUpdated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributes** | [**BaseAttributesCreatedUpdatedAttributes**](BaseAttributesCreatedUpdatedAttributes.md) |  | [optional] 


