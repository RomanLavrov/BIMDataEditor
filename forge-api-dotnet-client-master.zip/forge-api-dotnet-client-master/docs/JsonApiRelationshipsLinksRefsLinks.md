# Autodesk.Forge.Model.JsonApiRelationshipsLinksRefsLinks
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Self** | [**JsonApiLink**](JsonApiLink.md) |  | 
**Related** | [**JsonApiLink**](JsonApiLink.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

