# ForgeSdk.ItemRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**tip** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**versions** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 
**refs** | [**JsonApiRelationshipsLinksRefs**](JsonApiRelationshipsLinksRefs.md) |  | 


