# ForgeSdk.JsonApiTypeId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | resource id | 
**type** | **String** | resource type | 


