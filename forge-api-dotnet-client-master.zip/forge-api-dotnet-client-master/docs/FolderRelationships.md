# Autodesk.Forge.Model.FolderRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Parent** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | [optional] 
**Contents** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 
**Refs** | [**JsonApiRelationshipsLinksRefs**](JsonApiRelationshipsLinksRefs.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

