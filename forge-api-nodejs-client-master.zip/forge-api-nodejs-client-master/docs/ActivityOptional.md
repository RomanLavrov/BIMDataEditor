# ForgeSdk.ActivityOptional

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**instruction** | **Object** |  | [optional] 
**appPackages** | **[String]** |  | [optional] 
**requiredEngineVersion** | **String** |  | [optional] 
**parameters** | **Object** |  | [optional] 
**allowedChildProcesses** | **[Object]** |  | [optional] 
**version** | **Integer** |  | [optional] 
**description** | **String** |  | [optional] 
**hostApplication** | **String** |  | [optional] 
**isPublic** | **Boolean** |  | [optional] 


