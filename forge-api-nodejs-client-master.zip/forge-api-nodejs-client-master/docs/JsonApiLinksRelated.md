# ForgeSdk.JsonApiLinksRelated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**related** | [**JsonApiLink**](JsonApiLink.md) |  | 


