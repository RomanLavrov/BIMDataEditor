# ForgeSdk.JobPayloadOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**formats** | [**[JobPayloadItem]**](JobPayloadItem.md) | Group of requested formats/types. User can request multiple formats. | 


