# ForgeSdk.DesignAutomationActivities

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[Activity]**](Activity.md) |  | [optional] 


