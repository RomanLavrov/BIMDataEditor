# ForgeSdk.CreateRefData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**id** | **String** |  | 
**meta** | [**CreateRefDataMeta**](CreateRefDataMeta.md) |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `folders` (value: `"folders"`)

* `items` (value: `"items"`)

* `versions` (value: `"versions"`)




