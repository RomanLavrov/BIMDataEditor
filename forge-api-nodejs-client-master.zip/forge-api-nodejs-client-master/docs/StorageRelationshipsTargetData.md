# ForgeSdk.StorageRelationshipsTargetData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**id** | **String** |  | 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `folders` (value: `"folders"`)




