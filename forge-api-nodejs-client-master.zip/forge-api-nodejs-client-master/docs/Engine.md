# ForgeSdk.Engine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**resource** | **String** |  | [optional] 
**isPublic** | **Boolean** |  | [optional] 
**version** | **Integer** |  | [optional] 
**timestamp** | **String** |  | [optional] 
**description** | **String** |  | [optional] 


