# Autodesk.Forge.Model.JsonApiLinksPaging
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**First** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**Prev** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**Next** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 
**Last** | [**JsonApiLink**](JsonApiLink.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

