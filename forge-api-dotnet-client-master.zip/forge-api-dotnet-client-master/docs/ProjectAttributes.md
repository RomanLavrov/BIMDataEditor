# Autodesk.Forge.Model.ProjectAttributes
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | displayable name of the project | 
**Extension** | [**BaseAttributesExtensionObject**](BaseAttributesExtensionObject.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

