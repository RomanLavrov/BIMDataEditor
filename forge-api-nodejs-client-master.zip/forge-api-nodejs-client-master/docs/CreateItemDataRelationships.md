# ForgeSdk.CreateItemDataRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tip** | [**CreateItemDataRelationshipsTip**](CreateItemDataRelationshipsTip.md) |  | [optional] 
**parent** | [**CreateStorageDataRelationshipsTarget**](CreateStorageDataRelationshipsTarget.md) |  | [optional] 


