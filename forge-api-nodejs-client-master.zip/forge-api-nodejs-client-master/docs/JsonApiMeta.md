# ForgeSdk.JsonApiMeta

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


