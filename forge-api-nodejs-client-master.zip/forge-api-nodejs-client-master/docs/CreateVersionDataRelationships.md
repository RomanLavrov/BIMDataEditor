# ForgeSdk.CreateVersionDataRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**item** | [**CreateVersionDataRelationshipsItem**](CreateVersionDataRelationshipsItem.md) |  | [optional] 
**storage** | [**CreateItemRelationshipsStorage**](CreateItemRelationshipsStorage.md) |  | [optional] 


