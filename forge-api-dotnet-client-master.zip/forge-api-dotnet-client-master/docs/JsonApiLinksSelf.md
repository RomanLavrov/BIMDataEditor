# Autodesk.Forge.Model.JsonApiLinksSelf
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Self** | [**JsonApiLink**](JsonApiLink.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

