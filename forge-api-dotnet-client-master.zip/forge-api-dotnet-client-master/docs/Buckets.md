# Autodesk.Forge.Model.Buckets
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Items** | [**List&lt;BucketsItems&gt;**](BucketsItems.md) | Array of items representing the buckets | 
**Next** | **string** | Next possible request | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

