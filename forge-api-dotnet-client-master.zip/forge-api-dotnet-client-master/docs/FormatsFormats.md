# Autodesk.Forge.Model.FormatsFormats
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Svf** | **List&lt;string&gt;** |  | [optional] 
**Thumbnail** | **List&lt;string&gt;** |  | [optional] 
**Stl** | **List&lt;string&gt;** |  | [optional] 
**Step** | **List&lt;string&gt;** |  | [optional] 
**Iges** | **List&lt;string&gt;** |  | [optional] 
**Obj** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

