# ForgeSdk.WorkItemResp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**_arguments** | **Object** |  | [optional] 
**status** | **String** |  | [optional] 
**statusDetail** | **Object** |  | [optional] 
**availabilityZone** | **String** |  | [optional] 
**activityId** | **String** |  | [optional] 
**version** | **Integer** |  | [optional] 
**timestamp** | **String** |  | [optional] 
**timeQueued** | **String** |  | [optional] 
**timeInputTransferStarted** | **String** |  | [optional] 
**timeScriptStarted** | **String** |  | [optional] 
**timeScriptEnded** | **String** |  | [optional] 
**timeOutputTransferEnded** | **String** |  | [optional] 
**bytesTranferredIn** | **Integer** |  | [optional] 
**bytesTranferredOut** | **Integer** |  | [optional] 


