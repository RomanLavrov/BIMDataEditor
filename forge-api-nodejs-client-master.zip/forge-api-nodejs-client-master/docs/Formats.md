# ForgeSdk.Formats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**formats** | [**FormatsFormats**](FormatsFormats.md) |  | [optional] 


