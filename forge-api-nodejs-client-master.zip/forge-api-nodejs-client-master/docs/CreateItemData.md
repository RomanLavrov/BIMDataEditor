# ForgeSdk.CreateItemData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**attributes** | [**CreateStorageDataAttributes**](CreateStorageDataAttributes.md) |  | [optional] 
**relationships** | [**CreateItemDataRelationships**](CreateItemDataRelationships.md) |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `items` (value: `"items"`)




