# Autodesk.Forge.Model.DesignAutomationWorkItems
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | [**List&lt;WorkItemResp&gt;**](WorkItemResp.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

