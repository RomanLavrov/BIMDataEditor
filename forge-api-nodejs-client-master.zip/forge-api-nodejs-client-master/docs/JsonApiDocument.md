# ForgeSdk.JsonApiDocument

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**JsonApiResource**](JsonApiResource.md) |  | 
**included** | [**[JsonApiResource]**](JsonApiResource.md) |  | [optional] 
**links** | [**JsonApiLinksSelf**](JsonApiLinksSelf.md) |  | 


