# ForgeSdk.DesignAutomationAppPackages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[AppPackage]**](AppPackage.md) |  | [optional] 


