# ForgeSdk.JsonApiMetaLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | [**JsonApiLink**](JsonApiLink.md) |  | 


