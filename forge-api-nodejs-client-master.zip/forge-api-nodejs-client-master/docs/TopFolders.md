# ForgeSdk.TopFolders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersion**](JsonApiVersion.md) |  | 
**links** | [**JsonApiLinksSelf**](JsonApiLinksSelf.md) |  | 
**data** | [**[Folder]**](Folder.md) |  | 


