# ForgeSdk.Buckets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[BucketsItems]**](BucketsItems.md) | Array of items representing the buckets | 
**next** | **String** | Next possible request | 


