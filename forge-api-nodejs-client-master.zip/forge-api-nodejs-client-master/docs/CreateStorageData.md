# ForgeSdk.CreateStorageData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**attributes** | [**CreateStorageDataAttributes**](CreateStorageDataAttributes.md) |  | [optional] 
**relationships** | [**CreateStorageDataRelationships**](CreateStorageDataRelationships.md) |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `objects` (value: `"objects"`)




