# ForgeSdk.BaseAttributesExtensionObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**version** | **String** |  | 
**schema** | [**JsonApiLink**](JsonApiLink.md) |  | 
**data** | **Object** |  | [optional] 


