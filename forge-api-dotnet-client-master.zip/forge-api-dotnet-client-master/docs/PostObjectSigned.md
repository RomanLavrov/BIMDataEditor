# Autodesk.Forge.Model.PostObjectSigned
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SignedUrl** | **string** | URL created for downloading the object | 
**Expiration** | **long?** | Value for expiration in minutes | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

