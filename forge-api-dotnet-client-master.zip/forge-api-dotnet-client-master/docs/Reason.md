# Autodesk.Forge.Model.Reason
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Reason** | **string** | reason for failure | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

