# ForgeSdk.AppPackageOptional

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**resource** | **String** |  | [optional] 
**references** | **[String]** |  | [optional] 
**requiredEngineVersion** | **String** |  | [optional] 
**version** | **Integer** |  | [optional] 
**description** | **String** |  | [optional] 
**isPublic** | **Boolean** |  | [optional] 
**isObjectEnabler** | **Boolean** |  | [optional] 


