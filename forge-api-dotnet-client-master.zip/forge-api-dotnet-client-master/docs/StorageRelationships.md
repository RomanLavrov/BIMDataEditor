# Autodesk.Forge.Model.StorageRelationships
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Target** | [**StorageRelationshipsTarget**](StorageRelationshipsTarget.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

