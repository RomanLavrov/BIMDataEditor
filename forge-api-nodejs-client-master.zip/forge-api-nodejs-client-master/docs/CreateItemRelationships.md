# ForgeSdk.CreateItemRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storage** | [**CreateItemRelationshipsStorage**](CreateItemRelationshipsStorage.md) |  | [optional] 


