# ForgeSdk.Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**code** | **String** |  | 
**message** | **[String]** |  | 


