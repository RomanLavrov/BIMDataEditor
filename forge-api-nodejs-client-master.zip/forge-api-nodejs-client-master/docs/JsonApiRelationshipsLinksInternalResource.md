# ForgeSdk.JsonApiRelationshipsLinksInternalResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**JsonApiLinksRelated**](JsonApiLinksRelated.md) |  | 
**data** | [**JsonApiTypeId**](JsonApiTypeId.md) |  | 


