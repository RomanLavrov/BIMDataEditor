# ForgeSdk.CreateVersionData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**attributes** | [**CreateStorageDataAttributes**](CreateStorageDataAttributes.md) |  | [optional] 
**relationships** | [**CreateVersionDataRelationships**](CreateVersionDataRelationships.md) |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `versions` (value: `"versions"`)




