# Autodesk.Forge.Model.JobPayloadOutput
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Formats** | [**List&lt;JobPayloadItem&gt;**](JobPayloadItem.md) | Group of requested formats/types. User can request multiple formats. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

