# Autodesk.Forge.Model.PostBucketsSigned
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinutesExpiration** | **int?** | Expiration time in minutes Default value: 60  | [default to 60]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

